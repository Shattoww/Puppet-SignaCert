#!/bin/sh
#
# This script launches the client from an SSH connection initiated by the ETS.
# Its primary purpose is to allow customers to substitute a custom script
# for performing snapshots and verifications. It will look for the file
# custom.sh in the remote subdirectory of the signaclient install location.
# If such a file exists, it will be executed. Otherwise, we will launch
# the the signaclient javalauncher. In either case, all the arguments
# given to this script will be passed on to the subsequent script.
#
# If the environment variable SIGNACERT_HOME is set, it will be used
# to find the files necessary to run the client. If it is not set
# the script will make its best attempt to locate the installed
# directory on its own.

# If you wish to set the install path manually uncomment and set the following
# line correctly.
# SIGNACERT_HOME=/opt/signacert

# resolve links - $0 may be a softlink
PRG="$0"

while [ -h "$PRG" ]; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
    PRG="$link"
  else
    PRG=`dirname "$PRG"`/"$link"
  fi
done

# Get standard environment variables
PRGDIR=`dirname "$PRG"`

# Only set SIGNACERT_HOME if not already set
if [ -z "$SIGNACERT_HOME" ]
then
    SIGNACERT_HOME=`cd "$PRGDIR/../.." ; pwd`
    export SIGNACERT_HOME 
fi

INSTALL_PATH=${SIGNACERT_HOME}/signaclient
JRE=${SIGNACERT_HOME}/jre
REMOTE_PATH=${INSTALL_PATH}/remote

if [ -f "$REMOTE_PATH/custom.sh" -a -x "$REMOTE_PATH/custom.sh" ]; then
  exec "$REMOTE_PATH/custom.sh" $@
fi

exec $INSTALL_PATH/signaclient $@
